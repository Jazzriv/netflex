$(document).ready(function(){
	$('#hello_tr').on('dragstart', function(event) { event.preventDefault(); });
	$('#helloverlay').delay(1500).fadeTo(500, 0);
	$('#helloverlay').hide(1800);
});

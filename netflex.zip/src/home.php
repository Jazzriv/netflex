<?php include'start_session.php';
include 'user_ui.php'; ?>
	<DIV id="helloverlay">
			<DIV id="wrapper">
				<table id = "table">
					<tr>
						<td id="hello_td" ><img id = "hello_logo" src="../img/netflex_logo_dark.png"></td>
					</tr>
					<tr>
						<td id = "message">Welcome.</td>
					</tr>
				</table>
			</DIV>
		</DIV>



	<script src="jquery-3.1.1.js"></script>
	<script src="jquery-ui.js"></script>
	<script src = "user_ui.js"></script>
	<script src = "hello.js"></script>
	</BODY>
</HTML>
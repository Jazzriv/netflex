$(document).ready(function() { 
  	function addSearch(){
  		$.ajax({
  			type:"GET",
  			url : "process.php",
  			data : {action : "supplementarySearch"},
  			success : function(data){
  				$("#content").html(data);
  			}
  		});
  	}
  	addSearch();
});
<?php
	if(isset($_POST['identifier1']) && isset($_POST['password1'])){
		$username = trim($_POST['identifier1']);
		$password = trim($_POST['password1']);
		 if( empty($username) || empty($password) )
	  {
	  	echo "Le nom d'utilisateur et mot de passe sont nécessaires.";
		exit();
	  }
    	$id=CheckLogin($bdd, $username,$password);
    	$_POST["id"] = $id;

	}

	function CheckLogin($bdd, $username,$password){
		$query = "SELECT id, name, password FROM users WHERE name='$username' and password='$password' ";
 		$result = mysqli_query($bdd, $query);
     
 	   if(!$result || mysqli_num_rows($result) <= 0){
    	    $bdd->HandleError("Error logging in. The username or password does not match");
   			return false;
		}
		$query = "SELECT id FROM users WHERE name='$username' and password = '$password'";
		$result = mysqli_query($bdd, $query);
		$array = mysqli_fetch_assoc($result);
		return $array["id"];
	}
?>
<?	
	include 'start_session.php';
	session_destroy();
	header( 'location: accueil.php' );
?>
<div class= "content">
	<div class="content_container">
		<br/>
	<?php
//vérification préliminaire de la présence d'une recherche
if(isset($_GET["searchbar"])&& $_GET["searchbar"]!=''){
	//Sécurisation de l'input
	$typed=htmlspecialchars($_GET["searchbar"]);
	//Préparation de la recherche
	$search= explode(" ", $typed);

	//Variables
	$target_page = "search.php";			//page de recherche	
	$start = 0;								//information définissant le début des limites de la requête SQL
	$limit = 20;							//nombre de résultats à afficher par page
	$total_results = "";					//nombre total de résultats
	$typed= str_replace(" ","+",$typed);	//recherche entrée par l'utilisateur

	//récupération du/des thème(s) sélectionné(s)
/*	$checked = $_GET["check_list"];
	echo $checked;
	ABANDONNE
*/		
	//compte des résultats
	$query = mysqli_prepare($bdd,"SELECT * FROM series WHERE name LIKE ?");
	
	foreach($search as $word){
		$word="%".$word."%";
		mysqli_stmt_bind_param($query,"s",$word);
	}
	$res = mysqli_stmt_execute($query);	
	$data = mysqli_stmt_fetch($query);
	echo $data;
	if(count($data)<= 0){//Si aucun résultat :
		echo("Aucun résultat ne correspond à votre recherche...");
	}
	else{//Sinon, récupération du nombre de résultats
		$total_results = count($data);
	}
	
	//recherche des résultats concernés
	$query = $mysqli->prepare("SELECT * FROM series WHERE name LIKE ? LIMIT $start, $limit");
	//Binding de chaque mot de la recherche à la requête
	foreach($search as $word){
		$word="%".$word."%";
		mysqli_stmt_bind_param($query,"s",$word);
	}
	$result = mysqli_stmt_execute($query);
	$to_show = mysqli_stmt_fetch($query);

	//Préparation de la mise en page de l'interface de navigation
	include('search_layout.php');
		
	//Affichage des résultats
	if($to_show){
		echo("Nous avons trouvé " . $total_results . " séries correspondantes.");
		for($i=0; $i<count($to_show); $i++){
			$data=$to_show[$i];
			//Pour chaque vidéo, on crée un url
			$video_url= "view.php?view=".$data['movie_id'];
			include("search_result.php");
		}	

	?>
	<p style="text-align:center;">
		<?php echo($layout);?>
		<br/>
	</p>
		<?php
	}
}
else{
	echo (' Nous ne trouvons pas votre série.');
}
?>
		<br/>
	</div>
</div>



<!--
//Vérification de la tranche de résultats

if($start>0){
		$start = ($page - 1) * $limit;
		$total_results = $_GET['rslt'];
	}
	else{
	-->
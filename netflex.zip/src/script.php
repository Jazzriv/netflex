<?php
$result = mysqli_query($bdd,"SELECT * FROM genres");

if (!$result) {
	trigger_error('Error in query ' . $bdd->error);
} else {
	foreach($result as $row){
		$genre_id=$row["id"];
		$txt0 = "<tr>";
		$txt1 = "<td>
							<input type = 'checkbox' name = 'check_list[]' value=". $genre_id." id = ". $genre_id."/>
						</td>
						<td>";
		$txt2 = "						</td>
					</tr>";
		echo $txt0;
		echo $txt1;
		echo $row['name'];
		echo $txt2;
	}
}
?>

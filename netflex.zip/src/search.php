<?php include 'start_session.php'; 
include 'user_ui.php'; 
include 'process_search.php'; ?>

		<script src="jquery-3.1.1.js"></script>
		<script src="jquery-ui.js"></script>
		<script src = "user_ui.js"></script>
	</BODY>
</HTML>
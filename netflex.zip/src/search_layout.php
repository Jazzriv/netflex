<?php
?>
<table>
	<tr>
<?php
for($i = 0; $i<5; $i++){
	foreach($to_show as $tile){
		$name = echo "'".$title['name']."'";
		?><td><input type="button" name=<?php $name; ?></td
	}
}

?>
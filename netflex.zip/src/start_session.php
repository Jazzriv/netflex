<?php
session_start();
$bdd;
if(isset($_POST['name']) && isset($_POST['password'])){
	$_SESSION['name'] = $_POST['name'];
	$_SESSION['password'] = $_POST['password'];
	$_SESSION['id'] = $_POST['id'];
	
}
// Create connection
	$bdd = new mysqli('localhost', 'root','','netflex-1');
	if($bdd->connect_errno){
		echo "La connection à la base de données a échoué (".$bdd->connect_errno.") ".$bdd->connect_error;
	}

?>
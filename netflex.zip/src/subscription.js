$(document).ready(function(){
	$("#ack").hide();
});
// When the user clicks the button, open the overlay modal
$("#popupbtn").on('click', function(){
	$('#overlay').show(500);
	$('#content').show(500);
});

// When the user clicks on <span> (x), close the modal
$(".close").on('click', function(){
	$('#overlay').hide(500);
	$('#content').hide(500);
});

// When the user clicks anywhere outside of the modal, close it
$(window).on('click', function(event){
	if($(event.target).is('#content')){
			$('#overlay').hide(500);
			$('#content').hide(500);
	}
});


//client side validation of sign in

$('#conbtn').on('click',function(){
	if(!($('#identifier1').val()=="") && !($('#password1').val()=="")){
		$("#conform").submit();
	}
});
//client side validation of sign up
$("#subbtn").click( function() {
	if( $("#identifier2").val() == "" || $("#password2").val() == "" ){
	  $("#ack").show();
	}
	else{
		$("#subform").submit();
	}
});


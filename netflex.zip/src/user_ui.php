
<!DOCTYPE HTML>
<HTML lang="fr">
	<HEAD>
		<title>Netflex< - Projet informatique</title>
		<meta charset = "utf-8"/>
		<link rel = "stylesheet" type="text/css" href="style_bright.css">
	</HEAD>
	
	<BODY>
		<HEADER>
			<DIV id = "topbar">
				<input type="button" onclick = "location.href = 'home.php' " id = "logo"/>
				<FORM id = "searchform" method = "get" action="search.php">
					<input type = "button" name = "themes" value = "Thèmes" id = "theme_button"/>
					<input type = "text" name="searchbar" placeholder = "Cherchez une série ..." id = "searchbar"/>
					<input type = "submit" value="" id="search_button" />
				</FORM>
				<button type = "button" name = "toggle" id = "toggle_navbar" value = ""/>
			</DIV>
		</HEADER>
		

		<DIV id="theme_div">
			<!--remplissage de la liste des thèmes -->
			<form name="themes" method="get">
				<table id = "themes_table">
					<?php include'script.php'; ?>
				</table>
			</form>
		</DIV>
		<ASIDE id = "navbar">
			<SECTION id="nav_element">
				<DIV id="user_tools">
					<img src = "../img/user_image_PLACEHOLDER.png" id = "user_image"/> 
					<?php //récupération du nom d'utilisateur
					if (isset($_SESSION['id'])){
						$id =  $_SESSION['id'];
						$query = mysqli_query($bdd,"SELECT name FROM users WHERE id LIKE $id");
						foreach($query as $row){
							echo $row['name'];
						}
					}
					?>
					<form  id="prof_log_button1">
						<input type = "button" onclick="location.href='logout.php'" name="profile" value="Profil"/>
					</form>
					<form action="logout.php" method="POST" id="prof_log_button2">
						<input type = "button" name="logout" value="Déconnexion"/>
					</form>
				</DIV>
			</SECTION>
			<SECTION id = "nav_element">
				Journal <br/>
				<table id = "news_table">
					<tr>
						<td id = "nav_section"> EXAMPLE 1 </td>
					</tr>
					<tr>
						<td id = "nav_section"> EXAMPLE 2 </td>
					</tr>
					<tr>
						<td id = "nav_section"> EXAMPLE 3 </td>
					</tr>
				</table>
			</SECTION>
			<SECTION id = "nav_element">
				Planning <br/>

			</SECTION>
		</ASIDE>
		
$("#subbtn").click( function() {
	if( $("#username").val() == "" || $("#pass").val() == "" )
	  $("#ack").html("Username/Password are mandatory fields -- Please Enter.");
	else
	 $.post( $("#subform").attr("action"),
	         $("#subform :input").serializeArray(),
			 function(info) {
 
			   $("#ack").empty();
			   $("#ack").html(info);
			 });
 
	$("#subform").submit( function() {
	   return false;	
	});
});

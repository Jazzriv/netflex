<?php

if(isset($_POST['identifier2']) && isset($_POST['password2'])){
		$username = mysqli_real_escape_string($bdd, $_POST['identifier2']);
		$email = mysqli_real_escape_string($bdd, $_POST['email']);
		$password = mysqli_real_escape_string($bdd, $_POST['password2']);
		 if( empty($username) || empty($password) )
	  {
	  	echo "Le nom d'utilisateur et mot de passe sont nécessaires.";
		exit();
	  }
	 $res = mysqli_query($bdd, "SELECT name, email FROM users WHERE name='$username' && email='$email'");
	 $row = mysqli_fetch_row($res);
 
	  if( $row > 0 )
	    echo "Username $username has already been taken";
	  else
	  {	  		
		$query = "INSERT INTO users (name, password, email) VALUES('$username','$password','$email')";
		$result = mysqli_query($bdd, $query);
		if(!$result){
			echo "requête invalide : ".mysql_error();
			die();
		}
		
		
	} 
	
}
?>
